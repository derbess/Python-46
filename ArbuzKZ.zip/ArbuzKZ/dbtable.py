class User():
    def __init__(self, connection):
        self.connection = connection

    def create_table(self):
        CREATE_TABLE = """
        CREATE TABLE user(
            id pk,
            username varchar(40) unique,
            firstname varchar(40),
            lastname varchar(40),
            email varchar(40) unique,
            mobile varchar(12) unique,
            password varchar(20),
            balance int,
            address varchar(40),
            isAdmin boolean
        )
        """
        cursor = self.connection.cursor()
        cursor.execute(CREATE_TABLE)
        print("Table user created")

    def insert_user(self, id, username, firstname, lastname, email, mobile, password, balance, address, isAdmin):
        cursor = self.connection.cursor()
        cursor.execute(f"INSERT INTO user VALUES({id}, '{username}', '{firstname}', '{lastname}', '{email}', '{mobile}', '{password}', {balance}, '{address}', {isAdmin})")
        self.connection.commit()
        print("data inserted")

    def get_all_user(self):
        cursor = self.connection.cursor()
        cursor.execute("SELECT * FROM user")
        data = cursor.fetchall()
        return data