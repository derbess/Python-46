from database_init import create_connection
from dbtable import *
connection = create_connection("arbuz")

users = User(connection)
# users.create_table()
users.insert_user(1, "derbes", "Derbes", "Utebaliyev", "derbes@gmail.com", "87777777777", "adminadmin", 10000, "Abai 52", False)
print(users.get_all_user())